This is an add-on powered by the Splunk Add-on Builder.
# Binary File Declaration
/opt/splunk/var/data/tabuilder/package/TA-puppet-alert-actions/bin/ta_puppet_alert_actions/aob_py2/markupsafe/_speedups.so: this file does not require any source code
/opt/splunk/var/data/tabuilder/package/TA-puppet-alert-actions/bin/ta_puppet_alert_actions/aob_py3/markupsafe/_speedups.cpython-37m-x86_64-linux-gnu.so: this file does not require any source code
